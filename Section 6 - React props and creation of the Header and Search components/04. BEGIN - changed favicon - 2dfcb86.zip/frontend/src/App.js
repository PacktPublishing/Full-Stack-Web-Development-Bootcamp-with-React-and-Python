const App = () => {
  return (
    <div>
      <h1>Images Gallery</h1>
    </div>
  );
}

export default App;
