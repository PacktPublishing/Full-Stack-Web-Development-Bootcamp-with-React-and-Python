import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/Header';

const App = () => {
  return (
    <div>
      <Header title="Images Gallery"/>
    </div>
  );
}

export default App;
